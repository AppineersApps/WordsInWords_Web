<?php
defined('BASEPATH') || exit('No direct script access allowed');

/**
 * Description of Go Ad Free Model
 *
 * @category webservice
 *
 * @package basic_appineers_master
 *
 * @subpackage models
 *
 * @module Go Ad Free
 *
 * @class Go_ad_free_model.php
 *
 * @path application\webservice\basic_appineers_master\models\Go_ad_free_model.php
 *
 * @version 4.4
 *
 * @author CIT Dev Team
 *
 * @since 27.09.2019
 */

class Go_ad_free_model extends CI_Model
{
    /**
     * __construct method is used to set model preferences while model object initialization.
     */
    public function __construct()
    {
        parent::__construct();
    }
}
